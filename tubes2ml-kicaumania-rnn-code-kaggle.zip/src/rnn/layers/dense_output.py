import numpy as np
from ...dense import DenseLayer

class DenseOutputLayer(DenseLayer):
    def __init__(self, units, vocab_size):
        super().__init__(units, vocab_size, init_method="zero")

    def set_weights(self, W_keras, b_keras):
        self.W = np.array(W_keras)
        self.b = np.array(b_keras).reshape(1, -1)

    def forward(self, inputs: np.ndarray) -> np.ndarray:
        logits = super().forward(inputs)
        shifted = logits - np.max(logits, axis=1, keepdims=True)
        exp = np.exp(shifted)
        return exp / np.sum(exp, axis=1, keepdims=True)
